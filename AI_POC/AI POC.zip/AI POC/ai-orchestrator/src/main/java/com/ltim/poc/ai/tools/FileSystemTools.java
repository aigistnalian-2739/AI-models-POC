package com.ltim.poc.ai.tools;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Description;
import java.io.IOException;
import java.nio.file.*;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

@Configuration
public class FileSystemTools {

    public record PathRequest(String path) {}
    public record WriteRequest(String path, String content) {}

    @Bean
    @Description("List all Java files in a directory recursively")
    public Function<PathRequest, List<String>> listFiles() {
        return request -> {
            try (var stream = Files.walk(Paths.get(request.path()))) {
                return stream.filter(Files::isRegularFile)
                        .map(Path::toString)
                        .filter(s -> s.endsWith(".java"))
                        .collect(Collectors.toList());
            } catch (IOException e) {
                return List.of("Error: " + e.getMessage());
            }
        };
    }

    @Bean
    @Description("Read the content of a specific text or java file")
    public Function<PathRequest, String> readFile() {
        return request -> {
            try {
                return Files.readString(Paths.get(request.path()));
            } catch (IOException e) {
                return "Error reading file: " + e.getMessage();
            }
        };
    }

    @Bean
    @Description("Write content to a file on disk")
    public Function<WriteRequest, String> writeFile() {
        return request -> {
            try {
                Path p = Paths.get(request.path());
                Files.createDirectories(p.getParent());
                Files.writeString(p, request.content());
                return "Successfully wrote to " + request.path();
            } catch (IOException e) {
                return "Error writing file: " + e.getMessage();
            }
        };
    }
}