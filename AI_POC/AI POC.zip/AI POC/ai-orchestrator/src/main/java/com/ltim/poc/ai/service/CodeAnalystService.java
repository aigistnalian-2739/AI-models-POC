package com.ltim.poc.ai.service;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;

@Service
public class CodeAnalystService {

    private final ChatClient architectAgent;
    private final ChatClient engineerAgent;
    private final ChatClient auditorAgent;

    public CodeAnalystService(ChatClient.Builder builder) {
        this.architectAgent = builder
                .defaultSystem("You are a Code Architect. Use tools to list and read files to understand architecture.")
                .build();

        this.engineerAgent = builder
                .defaultSystem("You are a QA Engineer. Generate OpenAPI YAML (with 400/404 errors) and JUnit 5 tests. Write them to disk.")
                .build();

        this.auditorAgent = builder
                .defaultSystem("You are a Code Auditor. Find missing Javadocs and poor error handling. Output a clean HTML table.")
                .build();
    }
    public String runPipeline(String path) {
        // Phase 1: The Architect reads the project to build a context map
        String summary = architectAgent.prompt()
                .system("""
                You are a Lead Architect. Analyze the project structure and source code.
                Focus on identifying REST Controllers, Request/Response DTOs, and Error Handling logic.
                DO NOT suggest changes to the code.
                """)
                .user("Analyze project structure and controllers at: " + path)
                .functions("listFiles", "readFile")
                .call().content();

        // Phase 2: The Engineer generates the documentation as a standalone YAML file
        return engineerAgent.prompt()
                .system("""
                You are a Senior API Engineer. Your task is to generate a professional 'openapi.yaml' file.
                
                STRICT CONSTRAINTS:
                1. DO NOT rewrite or modify any existing source code files. Treat them as READ-ONLY.
                2. Use the 'writeFile' tool ONLY to create: {path}/generated/openapi.yaml.
                3. The YAML must be OpenAPI 3.1.0 compliant.
                
                DOCUMENTATION REQUIREMENTS:
                - Detailed Schemas: Every DTO found must be fully defined in 'components/schemas'.
                - Error Handing: Every endpoint MUST include 400 (Bad Request), 404 (Not Found), and 500 (Server Error) responses.
                - Test Requests: Include 'example' and 'examples' for all request bodies and parameters.
                - Formats: Specify data formats (e.g., uuid, date-time, int64) accurately.
                """.replace("{path}", path))
                .user("Based on this summary: " + summary + ". Create the detailed openapi.yaml in the /generated folder.")
                .functions("writeFile")
                .call().content();
    }
    public String runAudit(String path) {
        return auditorAgent.prompt()
                .user("Audit the code quality at: " + path)
                .functions("listFiles", "readFile")
                .call().content();
    }

    // Inside CodeAnalystService.java
    public String runFullPipeline(String path) {
        // Phase 1: Context Gathering (Architect)
        String summary = architectAgent.prompt()
                .system("""
                You are a Lead Architect. Analyze the source code at the given path.
                Identify all REST endpoints, DTO structures, and data types.
                Produce a technical summary that includes field names, types, and constraints (e.g., @NotNull).
                """)
                .user("Extract API metadata from project at: " + path)
                .functions("listFiles", "readFile")
                .call().content();

        // Phase 2: High-Fidelity Artifact Generation (Engineer)
        return engineerAgent.prompt()
                .system("""
                You are a Senior API Engineer. Your task is to generate a 'comprehensive_openapi.yaml'.
                
                STRICT OUTPUT RULES:
                1. DO NOT modify any existing files. Treat source code as READ-ONLY.
                2. Use 'writeFile' to save ONLY to: {path}/generated/openapi.yaml.
                
                METADATA & SAMPLE DATA REQUIREMENTS:
                - Mock Inputs: Every request body must include a 'description' and 'example' with realistic mock data.
                - Response Samples: Provide '200 OK' samples and detailed error objects for 400, 404, and 500.
                - Schema Metadata: Include 'format' (email, uuid, int64), 'pattern' (regex), and 'default' values.
                - Templates: Use 'examples' (plural) for endpoints to show different scenarios (e.g., valid vs invalid input).
                - Server Info: Include a placeholder 'servers' section with 'dev' and 'staging' URLs.
                """.replace("{path}", path))
                .user("Based on this Architect Summary: " + summary + ". Generate the detailed OpenAPI YAML with mock data.")
                .functions("writeFile")
                .call().content();
    }
}