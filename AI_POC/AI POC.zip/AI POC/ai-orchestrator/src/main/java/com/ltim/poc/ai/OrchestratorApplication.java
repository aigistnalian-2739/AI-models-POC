package com.ltim.poc.ai;


import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.ai.openai.api.OpenAiApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.ai.chat.client.ChatClient;

@SpringBootApplication
public class OrchestratorApplication {

    public static void main(String[] args) {
        SpringApplication.run(OrchestratorApplication.class, args);
    }

    @Bean
    public ChatClient chatClient(ChatClient.Builder builder,
                                 @Value("${spring.ai.openai.api-key}") String apiKey) {

        // MANUALLY pointing to the GitHub Inference endpoint
        // GitHub's OpenAI-compatible endpoint is at the root, not /v1
        var openAiApi = new OpenAiApi("https://models.inference.ai.azure.com", apiKey);

        var chatModel = new OpenAiChatModel(openAiApi);

        return builder.build();
    }
}